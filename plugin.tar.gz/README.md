# waves-nativescript-signature-generator
    
## License

MIT
